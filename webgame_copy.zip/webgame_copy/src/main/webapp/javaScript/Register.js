let currentFormId = null; // Biến lưu ID của form hiện tại
var checkUsername = false;
var checkPassword = false;
var checkNickname = false;

function showForm(formId) {
    const form = document.getElementById(formId);

    // Nếu form hiện tại đang được hiển thị và không phải là form mới được ấn
    if (currentFormId && currentFormId !== formId) {
        const currentForm = document.getElementById(currentFormId);
        currentForm.classList.add('hidden'); // Ẩn form hiện tại
    }

    // Kiểm tra trạng thái hiện tại của form
    if (!form.classList.contains('hidden')) {
        // Nếu form đang hiển thị, thu lại nó
        form.classList.add('hidden');
        currentFormId = null; // Đặt lại biến lưu ID form hiện tại
    } else {
        // Nếu form đang ẩn, hiển thị nó
        form.classList.remove('hidden');
        currentFormId = formId; // Lưu ID của form hiện tại
    }
}

// 2 ham ngau loi
//------------------------------------------------------------------------
// Hàm kiểm tra mật khẩu
function validatePasswords() {
    checkPassword = false;
    var pass1 = document.getElementById('registerPassword').value;
    var pass2 = document.getElementById('registerConfirmPassword').value;
    var errorMessage = document.getElementById('passwordError');

    if (pass1 !== pass2) {
        errorMessage.style.display = 'inline';
    } else {
        errorMessage.style.display = 'none';
        checkPassword = true;
    }
}

// Hàm kiểm tra username khi người dùng nhập vào ô username (keyup event)
// Nó chỉ đóng vai trò hiện cảnh báo trùng. Hết
function checkUsernameKeyup() {
    checkUsername = false;
    var username = document.getElementById('registerUserName').value;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/RegisterController', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            var usernameTaken = document.getElementById('usernameTaken');

            if (response.exists) {
                console.log('Server response: the username exists');
                usernameTaken.style.display = 'inline';
            } else {
                console.log('Server response: Username is not exist, ok to use');
                usernameTaken.style.display = 'none';
                checkUsername = true;
            }
        }
    };
    xhr.send('username=' + encodeURIComponent(username));
}

// Hàm kiểm tra username khi người dùng nhập vào ô username (keyup event)
// Nó chỉ đóng vai trò hiện cảnh báo trùng. Hết
function checkNicknameKeyup() {
    checkNickname = false;
    var nickname = document.getElementById('registerNickname').value;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/RegisterController', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            var nicknameTaken = document.getElementById('nicknameTaken');

            if (response.exists) {
                console.log('Server response: the nickname is exists');
                nicknameTaken.style.display = 'inline';
            } else {
                console.log('Server response: Nickname is not exist, ok to use');
                nicknameTaken.style.display = 'none';
                checkNickname = true;
            }
        }
    };
    xhr.send('nickname=' + encodeURIComponent(nickname));
}
//------------------------------------------------------------------------

function validateForm() {
    if (checkUsername && checkPassword && checkNickname) {
        return true;
    } else {
        return false;
    }

}

function checkUsername() {
    var username = document.getElementById('registerUserName').value;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/RegisterController', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            var isUsernameValidInput = document.getElementById('isUsernameValid'); // Hidden input

            if (response.exists) {
                console.log('Server response: the username exists');
                isUsernameValidInput.value = "false"; // Set giá trị là false nếu username tồn tại
            } else {
                console.log('Server response: Username is not exist, ok to use');
                isUsernameValidInput.value = "true"; // Set giá trị là true nếu username không tồn tại
            }
        }
    };

    xhr.send('username=' + encodeURIComponent(username));
    // Không cần trả về giá trị, vì giá trị đã được gán vào hidden input
}



//--------------------------------------------------------------------------
//
//
//--------------------------------------------------------------------------
//
//// Hàm kiểm tra username khi người dùng nhấn nút "Register"
//function checkUsername() {
//    var username = document.getElementById('registerUserName').value;
//    var xhr = new XMLHttpRequest();
//    xhr.open('POST', '/LoginPageController', true);
//    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
//
//    var allowSubmit = true; // Biến để xác định xem có cho phép gửi form hay không
//
//    xhr.onreadystatechange = function () {
//        if (xhr.readyState === 4 && xhr.status === 200) {
//            var response = JSON.parse(xhr.responseText);
//            var usernameTaken = document.getElementById('usernameTaken');
//
//            if (response.exists) {
//                console.log('Server response: the username exists');
//                usernameTaken.style.display = 'inline';
//                allowSubmit = false; // Ngăn form gửi nếu username đã tồn tại
//            } else {
//                console.log('Server response: Username is not exist, ok to use');
//                usernameTaken.style.display = 'none';
//                allowSubmit = true; // Cho phép form gửi nếu username chưa tồn tại
//            }
//        }
//    };
//    // Gửi yêu cầu với parameter 'action=checkUsername' để phân biệt hành động
//    xhr.send('username=' + encodeURIComponent(username));
//    
//    return allowSubmit;
//}

